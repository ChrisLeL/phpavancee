<?php

namespace Presentation\Compta;

class Employe
{
}
