<?php
spl_autoload_register(function ($className) {
    $className = str_replace('\\', '/', $className); //sert à modifier \ en /
    $className = str_replace('Presentation', 'classes', $className);

    require_once __DIR__ . '/' . $className . '.php';
});
