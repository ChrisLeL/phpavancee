<?php

use Cocur\Slugify\Slugify;
use Presentation\Rh\Employe as RhEmploye;
use Presentation\Compta\Employe as ComptaEmploye;

require_once __DIR__ . '/vendor/autoload.php';

$slugger = new Slugify();

$slug = $slugger->slugify('Nicolas Sarkozy encore au tribunal');

var_dump($slug);

die();

// un employé pour la rh
$employe = new RhEmploye('Christopher', 'Lelievre', 30);
// un autre employé pour la compta

$employeCompta = new ComptaEmploye('Christopher', 'Lelievre', 30);

$employe->presentation();
